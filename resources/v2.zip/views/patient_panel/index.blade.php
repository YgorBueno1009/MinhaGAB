<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="{{getenv('APP_URL')}}/css/financial.css">
    <script defer src="https://kit.fontawesome.com/708b4765cf.js" crossorigin="anonymous"></script>
    <title>Painel do paciente</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <header class="main_header" style="width: 100%;">
        <h1>Painel do paciente</h1>
        <div class="buttons_box">
            <a href="{{route('logout')}}"><i class="fa-solid fa-right-from-bracket" title="logout"></i></a>
        </div>
    </header>

    <section class="gabs">
        <h1 class="page_title">Suas Gabs</h1>
        <table class="dash_table">
        <thead class="dash_table_header">
            <tr class="">
                <th>Status</th>
                <th>Expira em</th>
                <th>Clínica</th>
                <th>Download</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($gabs as $gab)                
            <tr class="dash_table_column">
                <td class="tipo_entrada">{{strtoupper($gab['status'])}}</td>
                <td>24h</td>
                <td>{{{$clinic[$gab['clinic_id']]['name']}}}</td>
                <td><a href="{{route('download', $gab['id'])}}">Download</a></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    </section>
</body>
</html>