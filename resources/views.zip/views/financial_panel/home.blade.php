@extends('layouts.financial')
@section('content')
<div class="dash_page">
    <h1 class="page_title">Home</h1>
</div>
@endsection
