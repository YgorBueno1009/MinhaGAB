<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="{{getenv('APP_URL')}}/csss/boot.css">
    <link rel="stylesheet" href="{{getenv('APP_URL')}}/csss/auth.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auth | MinhaGAB</title>
</head>
<body>
    @yield('content')
</body>
</html>
